Synthetic microscopy image set corresponding to the previously generated macrostructure characterization CSV.

Contents:
- 5 PNG images mapped to Img-1 through Img-5
- image_metadata.csv with parameters aligned to the prior dataset

Note:
These are synthetic example images for testing/demo/import workflows and are not real microscope acquisitions.
